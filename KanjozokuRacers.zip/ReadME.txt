**Kanjozoku Racers**

## Uputstva za upotrebu

1.Pri pokretanju aplikacije kliknuti START dugme

2.Ako se desi da apk neće da se pokrene to je do toga što automobili se stvaraju u traci u kojoj je naš autić i samim tim 
dolazi do sudara i prekida se aplikacija s toga je potrebno da se nekoliko puta pritiska START kako bi igrica krenula

3.Zute linije su mesta po kojima se nas autić kreće i pritiskom na njih pomeramo ga po autoputu

4.Brzina se povećava dok igramo i tako igrica postaje progresivnija i zahtevnija po igrača

5.Na kraju sesije prikazuje se SCORE koji je igrač ostvario u trenutnoj sesiji
