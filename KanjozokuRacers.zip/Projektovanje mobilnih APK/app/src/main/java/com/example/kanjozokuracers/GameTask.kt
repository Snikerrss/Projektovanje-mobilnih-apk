package com.example.kanjozokuracers

interface GameTask
{
    fun closeGame(mScore:Int)

}